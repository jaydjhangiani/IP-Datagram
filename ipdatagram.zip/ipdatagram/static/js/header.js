let flag=0,fragmentation_offset=0,tl=0;
function ipDatagram(){
    let hex = document.getElementById('hexInput').value;
    let ver = convert(hex.slice(0,1))+' Bytes';
    let hlen = convert(hex.slice(1,2)) * 4+' Bytes';
    let st = convert(hex.slice(2,4));
    //checkServiceType(st);
    tl = convert(hex.slice(4,8))+' Bytes';
    let id = convert(hex.slice(8,12));
    let dummy = (hex.slice(12,16));
    //console.log(dummy);
    to_binary(dummy);
    let ttl = convert(hex.slice(16,18))+' Hops';
    let p = convert(hex.slice(18,20));
    let protocol = getProtocol(p);
    let hc = convert(hex.slice(20,24))+' Bytes';
    let sa = convert(hex.slice(24,26))+"."+convert(hex.slice(26,28))+"."+convert(hex.slice(28,30))+"."+convert(hex.slice(30,32));
    let da = convert(hex.slice(32,34))+"."+convert(hex.slice(34,36))+"."+convert(hex.slice(36,38))+"."+convert(hex.slice(38,40));
    console.log(hex);
    let msg = checkOption(tl);
    document.querySelector('#VER').textContent = ver;
    document.querySelector('#HLEN').textContent = hlen;
    document.querySelector('#ST').textContent = st;
    document.querySelector('#TL').textContent = tl;
    document.querySelector('#ID').textContent = id;
    document.querySelector('#FLAG').textContent = flag;
    document.querySelector('#FRAG').textContent = fragmentation_offset;
    document.querySelector('#TTL').textContent = ttl;
    document.querySelector('#PRO').textContent = protocol;
    document.querySelector('#HC').textContent = hc;
    document.querySelector('#SA').textContent = sa;
    document.querySelector('#DA').textContent = da;
    document.querySelector('#OPT').textContent = msg;

    console.log(ver,hlen,st,tl,id,flag,fragmentation_offset,ttl,protocol,hc,sa,da,msg);

    
}

function convert(hex){
    
    decimal_number = Number(hexToDec(hex));
    return decimal_number;
}

function hexToDec(s) {
    var i, j, digits = [0], carry;
    for (i = 0; i < s.length; i += 1) {
        carry = parseInt(s.charAt(i), 16);
        for (j = 0; j < digits.length; j += 1) {
            digits[j] = digits[j] * 16 + carry;
            carry = digits[j] / 10 | 0;
            digits[j] %= 10;
        }
        while (carry > 0) {
            digits.push(carry % 10);
            carry = carry / 10 | 0;
        }
    }
    return digits.reverse().join('');
}

function to_binary(num){
    b1 = Number(num.slice(0,1));
    b2 = Number(num.slice(1,2));
    b3 = Number(num.slice(2,3));
    b4 = Number(num.slice(3,4));
    bn0 = b1.toString(2);
    bn1 = b2.toString(2);
    bn2 = b3.toString(2);
    bn3 = b4.toString(2);
    bn0 = bn0.padStart(4,'0');
    bn1 = bn1.padStart(4,'0');
    bn2 = bn2.padStart(4,'0');
    bn3 = bn3.padStart(4,'0');
    //console.log(bn0,bn1,bn2,bn3);
    bnum = bn0+bn1+bn2+bn3;
    flag = bnum.slice(0,3)
    fragmentation_offset = bnum.slice(3,16);
    //console.log(flag,fragmentation_offset); 
}

function getProtocol(p){
    if (p === 17){
        return 'UDP';
    }
    else if(p === 6){
        return 'TCP';
    }
    else if(p === 1){
        return 'ICMP';
    }
    else if(p === 2){
        return 'IGMP';
    }
    else if(p === 89){
        return 'OSFP';
    }
    else{
        return 'error';
    }
}

function checkOption(tl){
    var msg;
    var total = Number(tl) - 20;
    if (total > 60){
        let excess = total - 60
        msg = "OPTIONAL : "+excess+" bytes";
    }
    else{
        msg = "NO OPTIONS"
    }
    return msg;
}

